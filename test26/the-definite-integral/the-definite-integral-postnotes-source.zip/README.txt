LaTeX source bundle for post-notes
======================================

Contents:
  the-definite-integral-postnotes.tex  - LaTeX source
  assets/      - images referenced by the source

To compile (requires LuaLaTeX, TeX Live 2024+, Libertinus fonts):

  latexmk -lualatex the-definite-integral-postnotes.tex

Alt text for images is included in \\includegraphics alt={...} options where available.
