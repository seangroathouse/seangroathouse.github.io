LaTeX source bundle for pre-notes
=====================================

Contents:
  the-definite-integral-prenotes.tex  - LaTeX source
  assets/      - images referenced by the source

To compile (requires LuaLaTeX, TeX Live 2024+, Libertinus fonts):

  latexmk -lualatex the-definite-integral-prenotes.tex

Alt text for images is included in \\includegraphics alt={...} options where available.
